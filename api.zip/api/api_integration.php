<?php
// API endpoint URL
$url = 'https://api.example.com/endpoint';

// API key or token
$api_key = 'YOUR_API_KEY';

// Set up HTTP headers
$headers = array(
    'Content-Type: application/json',
    'Authorization: Bearer ' . $api_key
);

// Initialize cURL session
$ch = curl_init($url);

// Set cURL options
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL session and fetch response
$response = curl_exec($ch);

// Check for cURL errors
if ($response === false) {
    die('Curl error: ' . curl_error($ch));
}

// Close cURL session
curl_close($ch);

// Parse the JSON response
$data = json_decode($response, true);

// Check if JSON decoding was successful
if ($data === null) {
    die('Error parsing JSON response');
}

// Process the data (you can customize this part based on the API response structure)
$result = $data['result'];

// Display the result or perform further operations
echo 'API Response:';
echo '<pre>';
print_r($result);
echo '</pre>';
?>
