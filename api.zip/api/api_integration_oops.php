<?php
class UserAPI {
    private $apiUrl;

    public function __construct($apiUrl) {
        $this->apiUrl = $apiUrl;
    }

    public function createUser($name, $email, $phone) {
        $data = [
            'name' => $name,
            'email' => $email,
            'phone' => $phone
        ];

        $response = $this->makeRequest('POST', '/users', $data);
        return json_decode($response, true);
    }

    public function getUser($userId) {
        $response = $this->makeRequest('GET', '/users/' . $userId);
        return json_decode($response, true);
    }

    // Add more methods for other API endpoints as needed

    private function makeRequest($method, $endpoint, $data = null) {
        $url = $this->apiUrl . $endpoint;
        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);

        if ($data) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            throw new Exception(curl_error($ch));
        }

        curl_close($ch);

        return $response;
    }
}

// Usage example:
$apiUrl = 'https://api.example.com';
$userApi = new UserAPI($apiUrl);

try {
    $user = $userApi->createUser('John Doe', 'john@example.com', '123-456-7890');
    echo 'User Created!<br>';
    echo 'Name: ' . $user['name'] . '<br>';
    echo 'Email: ' . $user['email'] . '<br>';
    echo 'Phone: ' . $user['phone'] . '<br>';
} catch (Exception $e) {
    echo 'Error: ' . $e->getMessage();
}
?>
